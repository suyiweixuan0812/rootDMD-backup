"""Full-test evaluation only. Reconstruct step 0; never update model weights."""
import datetime,gc,hashlib,json,os,random,time
from pathlib import Path
import numpy as np
from PIL import Image
import torch
import torch.distributed as dist
from diffusers import StableDiffusion3Pipeline
from peft import LoraConfig,get_peft_model
from flow_grpo.diffusers_patch.sd3_pipeline_dmd import generate_latents
from flow_grpo.diffusers_patch.train_dreambooth_lora_sd3 import encode_prompt
from flow_grpo.rewards import clip_score,aesthetic_score,pickscore_score,hpsv2_score

def atomic(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp');temporary.write_text(json.dumps(value,indent=2,ensure_ascii=False));temporary.replace(path)

def main():
    rank=int(os.environ['RANK']);local=int(os.environ['LOCAL_RANK']);world=int(os.environ['WORLD_SIZE'])
    assert world==16,'Keep the original 16-rank sampling assignment'
    torch.cuda.set_device(local);device=torch.device('cuda',local)
    dist.init_process_group('nccl',timeout=datetime.timedelta(minutes=30))
    torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=True;torch.backends.cudnn.allow_tf32=True
    spec=json.loads(Path(__file__).with_name('evaluation-spec.json').read_text())
    out=Path(spec['output_root']);out.mkdir(parents=True,exist_ok=True)
    configurations={}
    for run in spec['runs']:
        root=Path(run['root']);configurations[run['id']]=json.loads((root/'config.json').read_text())
        for step in range(1000,10001,1000):
            ckpt=root/'checkpoints'/f'checkpoint-{step}'/'lora'/'generator'
            assert (ckpt/'adapter_config.json').is_file(),str(ckpt)
            assert (ckpt/'adapter_model.safetensors').is_file(),str(ckpt)
    if rank==0:
        atomic(out/'evaluation-spec.json',spec)
        print('PREFLIGHT_ALL_10_CHECKPOINTS_PRESENT',flush=True)
    dist.barrier()
    dtype=torch.bfloat16
    pipeline=StableDiffusion3Pipeline.from_pretrained(os.environ['SD3_MODEL'],torch_dtype=dtype,variant=None,local_files_only=True)
    pipeline.vae.requires_grad_(False).eval().to(device=device,dtype=torch.float32)
    encoders=[pipeline.text_encoder,pipeline.text_encoder_2,pipeline.text_encoder_3]
    tokenizers=[pipeline.tokenizer,pipeline.tokenizer_2,pipeline.tokenizer_3]
    for component in encoders:component.requires_grad_(False).eval().to(device=device,dtype=dtype)
    targets=['attn.add_k_proj','attn.add_q_proj','attn.add_v_proj','attn.to_add_out','attn.to_k','attn.to_out.0','attn.to_q','attn.to_v']
    lc=LoraConfig(r=32,lora_alpha=64,init_lora_weights='gaussian',target_modules=targets)
    pipeline.transformer.requires_grad_(False)
    transformer=get_peft_model(pipeline.transformer,lc,adapter_name='generator')
    transformer.add_adapter('fake_score',lc)
    for name,p in transformer.named_parameters():
        if 'lora_' in name:p.data=p.data.float()
    transformer.set_adapter('generator');transformer.eval().requires_grad_(False).to(device)
    assert all(torch.count_nonzero(p).item()==0 for n,p in transformer.named_parameters() if 'lora_B' in n and '.generator.' in n)
    transformer.enable_gradient_checkpointing()  # matches saved configuration; inert in eval
    factories={'clipscore':clip_score,'aesthetic':aesthetic_score,'pickscore':pickscore_score,'hpsv2':hpsv2_score}
    scorers={}
    for name,factory in factories.items():
        scorers[name]=factory(device)
        if rank==0:print('SCORER_READY',name,flush=True)
    caches={}
    for run in spec['runs']:
        cfg=configurations[run['id']];prompt_file=Path(__file__).with_name('drawbench-test.txt')
        assert hashlib.sha256(prompt_file.read_bytes()).hexdigest()==spec['prompt_file_sha256']
        records=[{'index':i,'prompt':p,'metadata':{}} for i,p in enumerate(prompt_file.read_text().splitlines()) if p.strip()]
        records.sort(key=lambda r:r['index'])
        assert [r['index'] for r in records]==list(range(run['count']))
        local_records=records[rank::world]
        batches=[]
        with torch.no_grad():
            for start in range(0,len(local_records),4):
                batch=local_records[start:start+4]
                embeds,pooled=encode_prompt(encoders,tokenizers,[r['prompt'] for r in batch],cfg['train']['max_sequence_length'],device=device)
                batches.append((batch,embeds.detach(),pooled.detach()))
        caches[run['id']]=(local_records,batches)
    # Free text encoders after caching; generation/scoring stays on the same GPU.
    for component in encoders:component.to('cpu')
    torch.cuda.empty_cache()
    summary=[]
    # Evaluate all zero-step models before loading any trained generator.
    for step in [0,10000,*range(1000,10000,1000)]:
        for run in spec['runs']:
            started=time.time();id=run['id'];cfg=configurations[id];root=Path(run['root']);folder=out/id/f'step-{step}';part=folder/f'rank-{rank}';part.mkdir(parents=True,exist_ok=True)
            if step:
                ckpt=root/'checkpoints'/f'checkpoint-{step}'/'lora'/'generator'
                transformer.load_adapter(ckpt,adapter_name='generator',is_trainable=False,local_files_only=True)
                transformer.set_adapter('generator');transformer.eval().requires_grad_(False)
                for n,p in transformer.named_parameters():
                    if 'lora_' in n:p.data=p.data.float()
            total=pipeline.scheduler.config.num_train_timesteps;shift=pipeline.scheduler.config.shift
            values=[round(shift*(t/total)/(1+(shift-1)*(t/total)),6) for t in cfg['sample']['denoising_step_list'][:cfg['sample']['num_steps']]]
            sigmas=torch.tensor(values+[0.],device=device,dtype=torch.float32);size=cfg['resolution']//pipeline.vae_scale_factor
            records,batches=caches[id];atomic(part/'prompts.json',records)
            torch.manual_seed(cfg['eval']['seed']+rank);random.seed(cfg['eval']['seed']+rank);np.random.seed(cfg['eval']['seed']+rank)
            with torch.no_grad():
                for batch,embeds,pooled in batches:
                    initial=torch.randn(len(batch),transformer.config.in_channels,size,size,device=device,dtype=embeds.dtype)
                    x0,_=generate_latents(transformer,initial,embeds,pooled,sigmas,total,len(sigmas)-1,cfg['sample']['noise_level'],mixed_precision_dtype=dtype)
                    latents=x0.float()/pipeline.vae.config.scaling_factor+pipeline.vae.config.shift_factor
                    images=(pipeline.vae.decode(latents,return_dict=False)[0]/2+.5).clamp(0,1)
                    for record,img in zip(batch,images):
                        array=img.mul(255).round().byte().permute(1,2,0).cpu().numpy();Image.fromarray(array).save(part/f'{record["index"]:06d}.png')
            scored=[dict(r,scores={}) for r in records]
            with torch.no_grad():
                for name,scorer in scorers.items():
                    for start in range(0,len(scored),8):
                        batch=scored[start:start+8];pixels=[]
                        for r in batch:
                            with Image.open(part/f'{r["index"]:06d}.png') as im:pixels.append(np.array(im.convert('RGB'),copy=True))
                        images=torch.from_numpy(np.stack(pixels)).permute(0,3,1,2).to(device).float()/255
                        vals,_=scorer(images,[r['prompt'] for r in batch],[r.get('metadata',{}) for r in batch])
                        if torch.is_tensor(vals):vals=vals.detach().float().cpu().numpy()
                        vals=np.asarray(vals).reshape(-1);assert len(vals)==len(batch) and np.isfinite(vals).all()
                        for r,v in zip(batch,vals):r['scores'][name]=float(v)
            atomic(part/'scores.json',scored)
            gathered=[None]*world;dist.all_gather_object(gathered,scored)
            if rank==0:
                combined=sorted([r for group in gathered for r in group],key=lambda r:r['index'])
                assert [r['index'] for r in combined]==list(range(run['count']))
                means={name:float(np.mean([r['scores'][name] for r in combined],dtype=np.float64)) for name in factories}
                table={'CLIP Score':means['clipscore']*100,'Aesthetic Score':means['aesthetic'],'Pick Score':means['pickscore']*26,'HP Score':means['hpsv2']*100}
                result={'method':'SD3-Medium + RTDMD-v31-last','dataset':id,'step':step,'num_images':len(combined),'table':table,'raw_repository_means':means,'seconds':time.time()-started,'protocol':{'seed':42,'world_size':16,'generation_batch_per_rank':4,'scoring_batch_per_rank':8,'resolution':512,'nfe':4,'ema':bool(step),'initialization':'reconstructed original SD3-Medium + zero-output Gaussian LoRA' if step==0 else 'saved EMA generator LoRA','training':False,'evaluation_dataset':'DrawBench','eval_freq':1000,'prompt_file_source':'drawbench-test.txt','prompt_file_sha256':spec['prompt_file_sha256'],'unique_prompts':spec['unique_prompts'],'note':'All steps regenerate the full test set with identical rank assignment, seeds, batches, and sampler.'}}
                if step==0 and id!='pickscore':
                    first=out/'pickscore'/'step-0'
                    result['shared_initial_identical_pngs']=sum(hashlib.sha256((folder/f'rank-{r["index"]%world}/{r["index"]:06d}.png').read_bytes()).digest()==hashlib.sha256((first/f'rank-{r["index"]%world}/{r["index"]:06d}.png').read_bytes()).digest() for r in combined)
                    assert result['shared_initial_identical_pngs']==len(combined)
                atomic(folder/'per-image-scores.json',combined);atomic(folder/'metrics.json',result);summary.append(result);atomic(out/'summary.json',summary)
                print('STEP_RESULT '+json.dumps(result,separators=(',',':')),flush=True)
            dist.barrier();torch.cuda.empty_cache()
    if rank==0:print('FULL_STEP_EVALUATION_COMPLETE',flush=True)
    dist.destroy_process_group()

if __name__=='__main__':main()
