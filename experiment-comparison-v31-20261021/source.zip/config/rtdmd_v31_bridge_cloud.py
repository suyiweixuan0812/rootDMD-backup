"""v31 Bridge, 10000 outer steps, full DrawBench at zero and every 1000."""
import importlib.util, os
from pathlib import Path
from ml_collections import ConfigDict

def get_config(name='train'):
    if name not in {'train','smoke'}:raise ValueError(name)
    root=Path(__file__).resolve().parents[1]
    spec=importlib.util.spec_from_file_location('bridge',root/'config/rtdmd_path_is_bridge.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    c=module.get_config('bridge')
    c.method_name='rtdmd_v31_bridge'
    c.run_name=os.environ.get('DMD_RUN_NAME','sd3-rtdmd-v31-bridge-pickscore-10000')
    c.save_dir=os.environ.get('DMD_SAVE_DIR',str(root/'logs/rtdmd-v31-bridge'))
    c.num_epochs=20 if name=='smoke' else 10000
    c.save_freq=20 if name=='smoke' else 1000
    c.eval_freq=c.save_freq
    c.eval.dataset=str(root/'dataset/drawbench')
    c.eval.num_prompts=4 if name=='smoke' else 1000
    c.eval.final_num_prompts=c.eval.num_prompts
    c.eval.reward_fn=ConfigDict() # Scoring only: sequential four-scorer saved-PNG path.
    return c
