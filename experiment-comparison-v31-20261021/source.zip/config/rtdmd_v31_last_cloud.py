"""v31 last method with the submitted 16-A100 DMD experiment's common settings."""
import importlib.util
import os
from pathlib import Path


def get_config(name="train"):
    if name not in {"train", "smoke"}:
        raise ValueError(name)
    root = Path(__file__).resolve().parents[1]
    spec = importlib.util.spec_from_file_location("v31_last", root / "config/rtdmd_path_is_last.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    c = module.get_config("last")
    c.method_name = "rtdmd_v31_last"
    c.run_name = os.environ.get("DMD_RUN_NAME", "sd3-rtdmd-v31-last-pickscore-16a100-10000")
    c.save_dir = os.environ.get("DMD_SAVE_DIR", str(root / "logs/rtdmd-v31-last"))
    c.num_epochs = 20 if name == "smoke" else 10000
    c.save_freq = 20 if name == "smoke" else 1000
    c.eval_freq = c.save_freq
    c.eval.dataset = str(root / "dataset/pickscore")
    c.eval.num_prompts = 4 if name == "smoke" else 16
    c.eval.final_num_prompts = 4 if name == "smoke" else 2048
    return c
