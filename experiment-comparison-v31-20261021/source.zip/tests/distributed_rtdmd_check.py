"""Two CPU ranks: verify global-batch gradient, AdamW, EMA and branch metrics."""
import os
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from flow_grpo.rtdmd_distributed import average_metrics, assert_replicated
from flow_grpo.posterior_consistency import consistency_surrogate

dist.init_process_group("gloo")
rank, world = dist.get_rank(), dist.get_world_size()
torch.manual_seed(42)
model = torch.nn.Linear(3, 3, bias=False).double()
reference = torch.nn.Linear(3, 3, bias=False).double()
reference.load_state_dict(model.state_dict())
ddp = DDP(model)
opt = torch.optim.AdamW(model.parameters(), lr=3e-5, weight_decay=0)
refopt = torch.optim.AdamW(reference.parameters(), lr=3e-5, weight_decay=0)
ema = {n: p.detach().clone() for n, p in model.named_parameters()}
refema = {n: p.detach().clone() for n, p in reference.named_parameters()}
inputs = torch.arange(world * 3).reshape(world, 3).double() / 10 + .1
for iteration in range(3):
    opt.zero_grad(); refopt.zero_grad()
    out = ddp(inputs[rank:rank + 1])
    loss = consistency_surrogate(out, torch.ones_like(out)*.2, torch.ones_like(out)*.5, .1, True)
    loss.backward()
    losses = []
    for row in inputs:
        prediction = reference(row[None])
        losses.append(consistency_surrogate(prediction, torch.ones_like(prediction)*.2,
                                           torch.ones_like(prediction)*.5, .1, True))
    torch.stack(losses).mean().backward()
    for p, q in zip(model.parameters(), reference.parameters()):
        torch.testing.assert_close(p.grad, q.grad, rtol=1e-6, atol=1e-8)
    assert_replicated({n: p.grad for n, p in model.named_parameters()}, "test_gradient")
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
    torch.nn.utils.clip_grad_norm_(reference.parameters(), 1.)
    opt.step(); refopt.step()
    for n, p in model.named_parameters():
        torch.testing.assert_close(p, dict(reference.named_parameters())[n], rtol=1e-6, atol=1e-8)
        # The report applies EMA every outer loop, including 9 unused rounds.
        for _ in range(10):
            ema[n].mul_(.99).add_(p.detach(), alpha=.01)
            refema[n].mul_(.99).add_(dict(reference.named_parameters())[n].detach(), alpha=.01)
        torch.testing.assert_close(ema[n], refema[n], rtol=1e-6, atol=1e-8)
    assert_replicated(ema, "test_ema")
metrics = {"common": float(rank + 1)}
if rank == 0:
    metrics["one_branch_only"] = 7.
averaged = average_metrics(metrics)
assert averaged == {"common": (world + 1)/2, "one_branch_only": 7.}
assert average_metrics({}) == {}
if rank == 0:
    print("DISTRIBUTED_RT_DMD_TEST_PASSED", flush=True)
dist.destroy_process_group()
