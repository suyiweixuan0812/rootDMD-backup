#!/usr/bin/env bash
set -euo pipefail
exec 2>&1
cd /root/code/ReFormFlow-main
python -m venv --system-site-packages /tmp/rtdmd-runtime
/tmp/rtdmd-runtime/bin/python -m pip install --disable-pip-version-check --no-cache-dir --no-index --find-links "$DMD_WHEELHOUSE" -r requirements-dmd-eval.txt
export PYTHONPATH=/root/code/ReFormFlow-main
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4
task_python=/tmp/rtdmd-runtime/bin/python
mkdir -p "$DMD_SAVE_DIR"
"$task_python" scripts/check_runtime.py --method dmd --model "$SD3_MODEL" --rewards pickscore clipscore aesthetic hpsv2
"$task_python" -c "import torch; assert torch.cuda.device_count()==8; assert all('A100' in torch.cuda.get_device_name(i) for i in range(8)); print('A100_PREFLIGHT_OK',flush=True)"
if [[ "$MLP_ROLE_INDEX" == 0 ]]; then
    "$task_python" -u jobs/relay_comparison.py > "$DMD_SAVE_DIR/relay.log" 2>&1 &
    relay_pid=$!
fi
launch=("$task_python" -u -m torch.distributed.run --nnodes=2 --nproc_per_node=8 --node_rank="$MLP_ROLE_INDEX" --master_addr="$MLP_WORKER_0_HOST" --master_port="${MLP_WORKER_0_PORT:-29500}")
"${launch[@]}" scripts/train_rtdmd_v31_bridge_sd3.py --config=config/rtdmd_v31_bridge_cloud.py:train
"${launch[@]}" scripts/benchmark_three_methods.py
if [[ "$MLP_ROLE_INDEX" == 0 ]]; then
    wait "$relay_pid"
    "$task_python" -c "from pathlib import Path; import os; p=Path(os.environ['DMD_SAVE_DIR'])/os.environ['DMD_RUN_NAME']; (p/'COMPLETED').write_text('Training, DrawBench evaluations, shared inference benchmark and private result export complete.'); print('BRIDGE_AND_COMPARISON_ARTIFACTS_COMPLETE',flush=True)"
fi
