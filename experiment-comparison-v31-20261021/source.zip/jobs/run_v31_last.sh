#!/usr/bin/env bash
set -euo pipefail
exec 2>&1
cd /root/code/ReFormFlow-main
python -m venv --system-site-packages /tmp/rtdmd-runtime
/tmp/rtdmd-runtime/bin/python -m pip install --disable-pip-version-check --no-cache-dir \
    --no-index --find-links "$DMD_WHEELHOUSE" -r requirements-dmd-eval.txt
export PYTHONPATH=/root/code/ReFormFlow-main
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false OMP_NUM_THREADS=4
task_python=/tmp/rtdmd-runtime/bin/python
"$task_python" scripts/check_runtime.py --method dmd --model "$SD3_MODEL" --rewards pickscore clipscore aesthetic hpsv2
"$task_python" - <<'PY'
import torch
assert torch.cuda.device_count() == 8, 'Expected eight GPUs per worker'
for i in range(8):
    p = torch.cuda.get_device_properties(i)
    assert 'A100' in p.name and p.total_memory > 75*1024**3, str(p)
print('A100_80GB_PREFLIGHT_OK count=8', flush=True)
PY
launch=("$task_python" -u -m torch.distributed.run --nnodes=2 --nproc_per_node=8
    --node_rank="$MLP_ROLE_INDEX" --master_addr="$MLP_WORKER_0_HOST" --master_port="${MLP_WORKER_0_PORT:-29500}")
"${launch[@]}" scripts/train_rtdmd_v31_last_sd3.py --config=config/rtdmd_v31_last_cloud.py:train
"${launch[@]}" scripts/score_dmd_images.py --run-dir "$DMD_SAVE_DIR/$DMD_RUN_NAME" \
    --step 10000 --expected-count 2048 --batch-size 8
"${launch[@]}" drawbench_step_eval.py
if [[ "$MLP_ROLE_INDEX" == 0 ]]; then
    "$task_python" - <<'PY'
import json, os
from pathlib import Path
root = Path(os.environ['DMD_SAVE_DIR']) / os.environ['DMD_RUN_NAME']
final = json.loads((root/'eval/step-10000/final-metrics.json').read_text())
assert final['num_images'] == 2048
summary = json.loads((root/'drawbench/summary.json').read_text())
assert sorted(row['step'] for row in summary) == list(range(0,10001,1000))
assert all(row['num_images'] == 1000 for row in summary)
(root/'COMPLETED.json').write_text(json.dumps({'method':'RTDMD-v31-last','training_steps':10000,
 'generator_updates':1000,'world_size':16,'pickscore':final,'drawbench':summary},indent=2))
print('RTDMD_V31_LAST_ALL_TRAINING_AND_FOUR_METRICS_COMPLETE',flush=True)
PY
fi
