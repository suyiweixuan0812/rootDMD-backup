"""Synchronization checks and branch-safe diagnostics for rank-local particles."""
import hashlib
import math
import torch
import torch.distributed as dist


def average_metrics(metrics):
    if not all(math.isfinite(float(v)) for v in metrics.values()):
        raise FloatingPointError("Nonfinite RTDMD diagnostics")
    if not dist.is_initialized():
        return metrics
    gathered = [None] * dist.get_world_size()
    dist.all_gather_object(gathered, metrics)
    keys = sorted(set().union(*(row.keys() for row in gathered)))
    # A diagnostic absent on an identity branch is missing, not a measured zero.
    return {key: sum(row[key] for row in gathered if key in row) /
                 sum(key in row for row in gathered) for key in keys}


def assert_replicated(tensors, label):
    digest = hashlib.sha256()
    for name, value in sorted(tensors.items()):
        digest.update(name.encode())
        if value is None:
            raise RuntimeError(f"Missing gradient/tensor: {label}: {name}")
        value = value.detach()
        if not torch.isfinite(value).all():
            raise FloatingPointError(f"Nonfinite tensor: {label}: {name}")
        digest.update(value.contiguous().cpu().view(torch.uint8).numpy().tobytes())
    fingerprint = digest.hexdigest()
    if dist.is_initialized():
        gathered = [None] * dist.get_world_size()
        dist.all_gather_object(gathered, fingerprint)
        if len(set(gathered)) != 1:
            raise RuntimeError(f"Rank synchronization failed: {label}: {gathered}")
    else:
        gathered = [fingerprint]
    if not dist.is_initialized() or dist.get_rank() == 0:
        print(f"REPLICA_CHECK_OK {label} ranks={len(gathered)} sha256={fingerprint}", flush=True)
