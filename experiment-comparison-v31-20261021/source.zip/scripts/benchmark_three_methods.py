"""Matched 16-A100 inference benchmark: identical cached text, CPS, VAE, seeds."""
import json,os,statistics,time,datetime
from pathlib import Path
import torch
import torch.distributed as dist
from diffusers import StableDiffusion3Pipeline
from peft import LoraConfig,get_peft_model
from flow_grpo.diffusers_patch.sd3_pipeline_dmd import generate_latents
from flow_grpo.diffusers_patch.train_dreambooth_lora_sd3 import encode_prompt

def main():
    rank=int(os.environ['RANK']);local=int(os.environ['LOCAL_RANK']);world=int(os.environ['WORLD_SIZE'])
    torch.cuda.set_device(local);device=torch.device('cuda',local)
    dist.init_process_group('nccl',timeout=datetime.timedelta(minutes=30))
    spec=json.loads(Path('comparison-spec.json').read_text());assert world==spec.get('world_size',16)
    torch.backends.cuda.matmul.allow_tf32=True;torch.backends.cudnn.allow_tf32=True
    dtype=torch.bfloat16
    pipe=StableDiffusion3Pipeline.from_pretrained(os.environ['SD3_MODEL'],torch_dtype=dtype,local_files_only=True)
    pipe.vae.requires_grad_(False).eval().to(device,dtype=torch.float32)
    encoders=[pipe.text_encoder,pipe.text_encoder_2,pipe.text_encoder_3]
    tokenizers=[pipe.tokenizer,pipe.tokenizer_2,pipe.tokenizer_3]
    for component in encoders:component.requires_grad_(False).eval().to(device,dtype=dtype)
    prompts=Path('dataset/drawbench/test.txt').read_text().splitlines();assert len(prompts)==1000
    prompts=prompts[:spec.get('num_images',1000)]
    local_prompts=prompts[rank::world];batches=[]
    with torch.no_grad():
        for start in range(0,len(local_prompts),4):
            ps=local_prompts[start:start+4]
            e,p=encode_prompt(encoders,tokenizers,ps,128,device=device);batches.append((len(ps),e,p))
    for component in encoders:component.to('cpu')
    target=['attn.add_k_proj','attn.add_q_proj','attn.add_v_proj','attn.to_add_out','attn.to_k','attn.to_out.0','attn.to_q','attn.to_v']
    pipe.transformer.requires_grad_(False)
    model=get_peft_model(pipe.transformer,LoraConfig(r=32,lora_alpha=64,init_lora_weights='gaussian',target_modules=target),adapter_name='generator')
    model.add_adapter('fake_score',model.peft_config['generator'])
    model.set_adapter('generator');model.eval().requires_grad_(False).to(device)
    total=pipe.scheduler.config.num_train_timesteps;shift=pipe.scheduler.config.shift
    sigmas=torch.tensor([round(shift*(s/total)/(1+(shift-1)*(s/total)),6) for s in [1000,750,500,250]]+[0.],device=device)
    @torch.no_grad()
    def generate(batch):
        n,embeds,pooled=batch
        initial=torch.randn(n,model.config.in_channels,64,64,device=device,dtype=embeds.dtype)
        x,_=generate_latents(model,initial,embeds,pooled,sigmas,total,4,.9,mixed_precision_dtype=dtype)
        pixels=(pipe.vae.decode(x.float()/pipe.vae.config.scaling_factor+pipe.vae.config.shift_factor,return_dict=False)[0]/2+.5).clamp(0,1)
        assert pixels.shape[0]==n
    results=[]
    for method in spec['methods']:
        checkpoint_step=method.get('step',10000)
        model.load_adapter(Path(method['root'])/f'checkpoints/checkpoint-{checkpoint_step}/lora/generator',adapter_name='generator',is_trainable=False,local_files_only=True)
        model.set_adapter('generator');model.eval().requires_grad_(False)
        for name,p in model.named_parameters():
            if 'lora_' in name:p.data=p.data.float()
        for batch in batches[:2]:generate(batch)
        repeats=[]
        for repeat in range(spec.get('repetitions',3)):
            torch.manual_seed(42+rank)
            torch.cuda.synchronize();dist.barrier();torch.cuda.reset_peak_memory_stats()
            start=time.perf_counter()
            for batch in batches:generate(batch)
            torch.cuda.synchronize()
            elapsed=time.perf_counter()-start
            values=torch.tensor([elapsed,torch.cuda.max_memory_allocated(),torch.cuda.max_memory_reserved()],device=device,dtype=torch.float64)
            dist.all_reduce(values,op=dist.ReduceOp.MAX)
            repeats.append({'seconds':values[0].item(),'peak_allocated_bytes_per_gpu':int(values[1].item()),'peak_reserved_bytes_per_gpu':int(values[2].item())})
        median=statistics.median(r['seconds'] for r in repeats)
        results.append({'method':method['id'],'num_images':len(prompts),'nfe':4,'world_size':world,
                        'median_seconds':median,'images_per_second_cluster':len(prompts)/median,'gpu_hours_per_1000':world*median/3600*1000/len(prompts),'repeats':repeats})
        if rank==0:print('INFERENCE_BENCHMARK '+json.dumps(results[-1]),flush=True)
    if rank==0:
        output=Path(spec['benchmark_file']);output.parent.mkdir(parents=True,exist_ok=True)
        tmp=output.with_suffix('.tmp')
        tmp.write_text(json.dumps({'scope':'Generation-only: cached identical text embeddings, four CPS steps and VAE decoding; no PNG I/O, model loading or scoring',
         'protocol':{'resolution':512,'seed':42,'world_size':world,'batch_per_rank':4,'warmup_batches':min(2,len(batches)),'repetitions':spec.get('repetitions',3),'sample_count':len(prompts)},'results':results},indent=2));tmp.replace(output)
    dist.barrier();dist.destroy_process_group()

if __name__=='__main__':main()
