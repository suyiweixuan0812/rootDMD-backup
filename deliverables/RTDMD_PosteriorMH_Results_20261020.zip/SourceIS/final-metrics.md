| Method | NFE | Post-Train | CLIP Score | Aesthetic Score | Pick Score | HP Score |
| --- | --- | --- | --- | --- | --- | --- |
| SD3-Medium + RTDMD Source-IS (corrected Scheme A) | 4 | Source-IS (no reward) | 19.5789 | 4.5526 | 17.9098 | 16.0197 |

PickScore test set: 2048 images; step 1000; EMA=True.

CLIP and HP scores use the ×100 display scale; Pick Score is the unnormalized logit. HP uses HPSv2.1. All four metrics score the same saved images. These values do not establish comparability with a paper using a different evaluation protocol.
