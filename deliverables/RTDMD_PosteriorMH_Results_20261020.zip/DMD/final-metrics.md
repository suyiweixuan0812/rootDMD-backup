| Method | NFE | Post-Train | CLIP Score | Aesthetic Score | Pick Score | HP Score |
| --- | --- | --- | --- | --- | --- | --- |
| SD3-Medium + DMD | 4 | DMD (no reward) | 25.5374 | 5.9152 | 20.3478 | 27.2742 |

PickScore test set: 2048 images; step 1000; EMA=True.

CLIP and HP scores use the ×100 display scale; Pick Score is the unnormalized logit. HP uses HPSv2.1. All four metrics score the same saved images. These values do not establish comparability with a paper using a different evaluation protocol.
