| Method | NFE | Post-Train | CLIP Score | Aesthetic Score | Pick Score | HP Score |
| --- | --- | --- | --- | --- | --- | --- |
| SD3-Medium + RTDMD Posterior-MH (Eq.2) | 4 | Posterior-MH (no reward) | 25.4264 | 5.9660 | 20.5580 | 28.3938 |

PickScore test set: 2048 images; step 1000; EMA=True.

CLIP and HP scores use the ×100 display scale; Pick Score is the unnormalized logit. HP uses HPSv2.1. All four metrics score the same saved images. These values do not establish comparability with a paper using a different evaluation protocol.
