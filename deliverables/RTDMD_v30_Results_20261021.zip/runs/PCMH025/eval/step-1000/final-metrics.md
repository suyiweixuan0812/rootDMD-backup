| Method | NFE | Post-Train | CLIP Score | Aesthetic Score | Pick Score | HP Score |
| --- | --- | --- | --- | --- | --- | --- |
| SD3-Medium + PC-MH lambda=0.25 | 4 | PC-MH lambda=0.25 | 26.1713 | 6.0386 | 20.8326 | 28.0147 |

PickScore test set: 2048 images; step 1000; EMA=True.

CLIP and HP scores use the ×100 display scale; Pick Score is the unnormalized logit. HP uses HPSv2.1. All four metrics score the same saved images. These values do not establish comparability with a paper using a different evaluation protocol.
