| Method | NFE | Post-Train | CLIP Score | Aesthetic Score | Pick Score | HP Score |
| --- | --- | --- | --- | --- | --- | --- |
| SD3-Medium + PC-MH lambda=0.50 | 4 | PC-MH lambda=0.50 | 26.2382 | 5.9494 | 20.7121 | 26.5751 |

PickScore test set: 2048 images; step 1000; EMA=True.

CLIP and HP scores use the ×100 display scale; Pick Score is the unnormalized logit. HP uses HPSv2.1. All four metrics score the same saved images. These values do not establish comparability with a paper using a different evaluation protocol.
